GeoDecor Studio - Live Block Catalog UI patch

What this patch adds
- A scrollable popup titled "Live Block Catalog".
- A summary showing total recognized objects, unique object IDs, and skipped objects.
- One row for every recognized object ID, with its count in the current level.
- The existing "Scan Current Level" button opens this full catalog instead of a ten-entry quick-popup summary.
- Read-only: the patch does not add, remove, move, or edit Geometry Dash objects.

Compatibility basis
- Uses geode::ScrollLayer, its CCSize create overload, m_contentLayer, and
  createDefaultListLayout, as declared in the current Geode ScrollLayer.hpp.
- Repository mod.json currently declares Geode 5.11.2 and Geometry Dash Android 2.2081.

Apply
1. Put this ZIP in the repository root and pull it into Codespaces, or extract it there.
2. From the repository root run:
     python3 apply.py
3. Then run:
     git diff --check
     git status --short
4. Do not commit until the source diff has been inspected and the Android64 CI build passes.

The script is guarded: it stops without changing src/main.cpp if expected anchors
are missing. It saves a pre-change copy to /tmp/geodecor-main.cpp.before-catalog-ui.
