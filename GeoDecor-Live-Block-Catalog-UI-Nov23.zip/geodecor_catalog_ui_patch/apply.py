#!/usr/bin/env python3
"""Safely add a scrollable read-only Live Block Catalog popup to GeoDecor Studio."""
from pathlib import Path
import sys

SOURCE = Path("src/main.cpp")
INCLUDE = '#include <Geode/ui/ScrollLayer.hpp>'
ANCHOR = "// ============================================================\n// GeoDecor Studio Workspace\n"
LOG_ANCHOR = (
    '        log::info(\n'
    '            "GeoDecor scanned {} objects across {} unique IDs.",\n'
)

POPUP_CLASS = r'''// ============================================================
// LIVE BLOCK CATALOG POPUP
// ============================================================

class GeoDecorBlockCatalogPopup : public geode::Popup {
protected:
    bool init(
        const std::vector<geodecor::BlockDNAEntry>& entries,
        std::size_t totalObjects,
        std::size_t invalidObjects
    ) {
        if (!geode::Popup::init(360.f, 290.f))
            return false;

        this->setTitle("Live Block Catalog");

        const auto size = m_mainLayer->getContentSize();
        const auto summaryText = fmt::format(
            "{} objects  |  {} unique IDs  |  {} skipped",
            totalObjects,
            entries.size(),
            invalidObjects
        );

        auto summary = CCLabelBMFont::create(
            summaryText.c_str(),
            "bigFont.fnt"
        );
        if (summary) {
            summary->setScale(0.34f);
            summary->setAlignment(kCCTextAlignmentCenter);
            summary->setPosition({size.width / 2.f, size.height - 42.f});
            m_mainLayer->addChild(summary);
        }

        // Geode's ScrollLayer clips long lists and supports touch scrolling.
        auto scroll = geode::ScrollLayer::create(
            CCSize{size.width - 36.f, size.height - 86.f}
        );
        if (!scroll)
            return false;

        scroll->setPosition({18.f, 18.f});
        m_mainLayer->addChild(scroll);

        scroll->m_contentLayer->setContentWidth(scroll->getContentWidth());
        scroll->m_contentLayer->setLayout(
            geode::ScrollLayer::createDefaultListLayout(4.f)
        );

        if (entries.empty()) {
            auto emptyLabel = CCLabelBMFont::create(
                "No valid object IDs were found.",
                "bigFont.fnt"
            );
            if (emptyLabel) {
                emptyLabel->setScale(0.42f);
                scroll->m_contentLayer->addChild(emptyLabel);
            }
        }
        else {
            for (const auto& entry : entries) {
                const auto rowText = fmt::format(
                    "Object ID: {}    Count: {}",
                    entry.objectId,
                    entry.count
                );

                auto row = CCLabelBMFont::create(
                    rowText.c_str(),
                    "bigFont.fnt"
                );
                if (!row)
                    continue;

                row->setScale(0.42f);
                row->setAnchorPoint({0.f, 0.5f});
                scroll->m_contentLayer->addChild(row);
            }
        }

        scroll->m_contentLayer->updateLayout();

        // Keep short inventories top-aligned; longer inventories scroll from the top.
        if (scroll->m_contentLayer->getContentHeight() < scroll->getContentHeight()) {
            const float difference =
                scroll->getContentHeight() - scroll->m_contentLayer->getContentHeight();
            scroll->m_contentLayer->setContentHeight(scroll->getContentHeight());

            for (auto child : CCArrayExt<CCNode*>(scroll->m_contentLayer->getChildren())) {
                child->setPositionY(child->getPositionY() + difference);
            }
        }

        const float scrollRange = std::max(
            0.f,
            scroll->m_contentLayer->getContentHeight() - scroll->getContentHeight()
        );
        scroll->m_contentLayer->setPositionY(-scrollRange);

        return true;
    }

public:
    static GeoDecorBlockCatalogPopup* create(
        const std::vector<geodecor::BlockDNAEntry>& entries,
        std::size_t totalObjects,
        std::size_t invalidObjects
    ) {
        auto ret = new GeoDecorBlockCatalogPopup();
        if (ret && ret->init(entries, totalObjects, invalidObjects)) {
            ret->autorelease();
            return ret;
        }

        CC_SAFE_DELETE(ret);
        return nullptr;
    }
};

'''


def main() -> int:
    if not SOURCE.is_file():
        print("ERROR: Run this script from the GeoDecor repository root (src/main.cpp was not found).")
        return 1

    source = SOURCE.read_text(encoding="utf-8")

    if "class GeoDecorBlockCatalogPopup" in source and INCLUDE in source:
        print("ALREADY APPLIED: the Live Block Catalog popup is already present.")
        return 0

    if INCLUDE not in source:
        popup_include = '#include <Geode/ui/Popup.hpp>'
        if popup_include not in source:
            print("ERROR: Expected Geode Popup include was not found; no changes made.")
            return 1
        source = source.replace(popup_include, popup_include + "\n" + INCLUDE, 1)

    if ANCHOR not in source:
        print("ERROR: Workspace insertion point did not match this main.cpp; no changes made.")
        return 1

    if "class GeoDecorBlockCatalogPopup" not in source:
        source = source.replace(ANCHOR, POPUP_CLASS + ANCHOR, 1)

    report_anchor = "        // Build the report.\n"
    if report_anchor not in source:
        print("ERROR: Scanner report section was not found; no changes made.")
        return 1

    report_start = source.index(report_anchor)
    log_start = source.find(LOG_ANCHOR, report_start)
    if log_start < 0:
        print("ERROR: Scanner logging section was not found; no changes made.")
        return 1

    catalog_call = '''        // Open the full, scrollable catalog instead of truncating the scan to ten IDs.
        auto catalog = GeoDecorBlockCatalogPopup::create(
            ranked,
            totalObjects,
            invalidObjects
        );

        if (catalog) {
            catalog->show();
        }
        else {
            geode::createQuickPopup(
                "Catalog Error",
                "The Live Block Catalog could not be created.",
                "Back",
                nullptr,
                nullptr
            );
        }

'''
    source = source[:report_start] + catalog_call + source[log_start:]

    backup = Path("/tmp/geodecor-main.cpp.before-catalog-ui")
    if not backup.exists():
        backup.write_text(SOURCE.read_text(encoding="utf-8"), encoding="utf-8")
    SOURCE.write_text(source, encoding="utf-8")

    print("SUCCESS: Added the scrollable Live Block Catalog popup to src/main.cpp.")
    print("The existing Scan Current Level button now opens the full object-ID inventory.")
    print("Backup saved to /tmp/geodecor-main.cpp.before-catalog-ui")
    print("No level objects are modified; this popup is read-only.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
