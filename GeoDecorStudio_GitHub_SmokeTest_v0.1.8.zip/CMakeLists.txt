cmake_minimum_required(VERSION 3.21)
project(GeoDecorStudio VERSION 0.1.8)

add_library(${PROJECT_NAME} SHARED
    src/main.cpp
)

setup_geode_mod(${PROJECT_NAME})
