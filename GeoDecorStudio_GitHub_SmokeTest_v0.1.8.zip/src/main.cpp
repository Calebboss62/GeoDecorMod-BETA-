#include <Geode/Geode.hpp>
#include <Geode/modify/MenuLayer.hpp>

using namespace geode::prelude;

// Minimal smoke-test hook. A successful Android64 build proves the
// repository's Geode project configuration and bindings compile.
// Loading the mod should produce this message in the Geode log.
class $modify(GeoDecorStudioMenuLayer, MenuLayer) {
    bool init() {
        if (!MenuLayer::init()) {
            return false;
        }

        log::info("GeoDecor Studio v0.1.8 loaded successfully.");
        return true;
    }
};
