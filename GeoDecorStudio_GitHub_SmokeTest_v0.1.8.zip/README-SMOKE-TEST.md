# GeoDecor Studio Android64 smoke test (v0.1.8)

This is a minimal Geode project intended to verify that GitHub Actions can compile
an Android64 `.geode` package for Geometry Dash Android 2.2081.

## Upload into the existing repository

1. Extract this ZIP.
2. Open https://github.com/Calebboss62/GeoDecorMod-BETA-
3. Choose **Add file → Upload files**.
4. Upload the extracted files and folders into the repository root.
   - Keep `mod.json` and `CMakeLists.txt` at the root.
   - Keep `main.cpp` inside `src/`.
   - Keep `android-smoke-test.yml` inside `.github/workflows/`.
5. Commit the upload to `main`.
6. Open **Actions** and select **GeoDecor Studio Android64 smoke test**.
7. If it succeeds, download the `GeoDecorStudio-Android64-smoke-test` artifact
   from that workflow run. It should contain the `.geode` file.

## What this test proves

- The repository contains a valid minimal Geode CMake project.
- The Geode SDK can compile the smoke-test hook for Android64.
- GitHub Actions can package and upload the resulting `.geode` artifact.

It does **not** prove the complete GeoDecor feature set works. This deliberately
small mod only logs `GeoDecor Studio v0.1.8 loaded successfully.` when loaded.

## If GitHub rejects the upload

The GitHub connection may need repository **Contents: Read and write** permission.
The assistant attempted to create these files directly, but GitHub returned HTTP 403
(`Resource not accessible by integration`). Uploading through the GitHub website is
the current workaround.

## Compatibility note

The metadata targets Android Geometry Dash 2.2081. The workflow requests the
latest Geode SDK release at build time. A successful compile is still required
before calling this artifact installable or tested in-game.
