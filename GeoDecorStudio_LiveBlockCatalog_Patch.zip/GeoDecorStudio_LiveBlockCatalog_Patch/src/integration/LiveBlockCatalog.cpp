#include "LiveBlockCatalog.hpp"

#include <Geode/Geode.hpp>

#include <utility>
#include <vector>

using namespace geode::prelude;

namespace geodecor {

BlockCatalogReport scanLiveBlockCatalog(cocos2d::CCArray* objects) {
    std::vector<BlockObjectSnapshot> snapshots;
    if (!objects) {
        return buildBlockCatalog(snapshots);
    }

    snapshots.reserve(objects->count());
    auto toolbox = ObjectToolbox::sharedState();

    for (unsigned int i = 0; i < objects->count(); ++i) {
        auto object = static_cast<GameObject*>(objects->objectAtIndex(i));
        if (!object) {
            continue;
        }

        BlockObjectSnapshot snapshot;
        snapshot.objectId = object->m_objectID;

        if (toolbox && snapshot.objectId > 0) {
            if (const char* frameName = toolbox->intKeyToFrame(snapshot.objectId)) {
                snapshot.frameName = frameName;
            }
        }

        snapshot.isSolidColorBlock = object->m_isSolidColorBlock;
        snapshot.isSlope = object->m_slopeUphill || object->m_slopeIsHazard;
        snapshot.isDecoration = object->m_isDecoration || object->m_isDecoration2;
        snapshot.hasGlowSprite = object->m_glowSprite != nullptr && !object->m_hasNoGlow;
        snapshot.isTrigger = object->m_isTrigger;
        snapshot.isStartPosition = object->m_isStartPos;
        snapshot.hasParticles = object->m_hasParticles;

        snapshots.push_back(std::move(snapshot));
    }

    return buildBlockCatalog(snapshots);
}

} // namespace geodecor
