#pragma once

#include "../core/BlockCatalog.hpp"

namespace cocos2d {
class CCArray;
}

namespace geodecor {

// Reads the objects already loaded in the editor. It does not create, move,
// delete, or otherwise modify Geometry Dash objects.
BlockCatalogReport scanLiveBlockCatalog(cocos2d::CCArray* objects);

} // namespace geodecor
