#include "BlockCatalog.hpp"

#include <algorithm>
#include <map>

namespace geodecor {
namespace {

bool matchesFilter(const BlockCatalogEntry& entry, BlockCatalogFilter filter) {
    switch (filter) {
        case BlockCatalogFilter::All:
            return true;
        case BlockCatalogFilter::NonTriggerObjects:
            return isSelectableDecorationObject(entry);
        case BlockCatalogFilter::SolidColorBlocks:
            return entry.isSolidColorBlock;
        case BlockCatalogFilter::Slopes:
            return entry.isSlope;
        case BlockCatalogFilter::Decorations:
            return entry.isDecoration;
        case BlockCatalogFilter::GlowObjects:
            return entry.hasGlowSprite;
        case BlockCatalogFilter::ParticleObjects:
            return entry.hasParticles;
        case BlockCatalogFilter::Triggers:
            return entry.isTrigger;
        case BlockCatalogFilter::StartPositions:
            return entry.isStartPosition;
    }
    return false;
}

} // namespace

bool isSelectableDecorationObject(const BlockCatalogEntry& entry) noexcept {
    return entry.objectId > 0 && !entry.isTrigger && !entry.isStartPosition;
}

BlockCatalogReport buildBlockCatalog(
    const std::vector<BlockObjectSnapshot>& snapshots) {
    BlockCatalogReport report;
    report.scannedObjects = snapshots.size();

    std::map<int, BlockCatalogEntry> inventory;

    for (const auto& snapshot : snapshots) {
        if (snapshot.objectId <= 0) {
            ++report.invalidObjectIds;
            continue;
        }

        auto [it, inserted] = inventory.try_emplace(snapshot.objectId);
        auto& entry = it->second;
        if (inserted) {
            entry.objectId = snapshot.objectId;
        }

        ++entry.count;
        if (entry.frameName.empty() && !snapshot.frameName.empty()) {
            entry.frameName = snapshot.frameName;
        }
        entry.isSolidColorBlock = entry.isSolidColorBlock || snapshot.isSolidColorBlock;
        entry.isSlope = entry.isSlope || snapshot.isSlope;
        entry.isDecoration = entry.isDecoration || snapshot.isDecoration;
        entry.hasGlowSprite = entry.hasGlowSprite || snapshot.hasGlowSprite;
        entry.isTrigger = entry.isTrigger || snapshot.isTrigger;
        entry.isStartPosition = entry.isStartPosition || snapshot.isStartPosition;
        entry.hasParticles = entry.hasParticles || snapshot.hasParticles;
    }

    report.entries.reserve(inventory.size());
    for (const auto& [id, entry] : inventory) {
        (void)id;
        report.entries.push_back(entry);
    }

    std::sort(report.entries.begin(), report.entries.end(),
        [](const BlockCatalogEntry& a, const BlockCatalogEntry& b) {
            if (a.count != b.count) {
                return a.count > b.count;
            }
            return a.objectId < b.objectId;
        });

    report.uniqueObjectIds = report.entries.size();
    for (const auto& entry : report.entries) {
        if (entry.hasGlowSprite) {
            ++report.objectTypesWithGlow;
        }
        if (entry.hasParticles) {
            ++report.objectTypesWithParticles;
        }
        if (isSelectableDecorationObject(entry)) {
            ++report.selectableObjectTypes;
        }
    }

    return report;
}

std::vector<int> getBlockCatalogIds(
    const BlockCatalogReport& report,
    BlockCatalogFilter filter) {
    std::vector<int> ids;
    ids.reserve(report.entries.size());

    for (const auto& entry : report.entries) {
        if (matchesFilter(entry, filter)) {
            ids.push_back(entry.objectId);
        }
    }
    return ids;
}

const BlockCatalogEntry* findBlockCatalogEntry(
    const BlockCatalogReport& report,
    int objectId) noexcept {
    const auto it = std::find_if(
        report.entries.begin(), report.entries.end(),
        [objectId](const BlockCatalogEntry& entry) {
            return entry.objectId == objectId;
        });
    return it == report.entries.end() ? nullptr : &*it;
}

} // namespace geodecor
