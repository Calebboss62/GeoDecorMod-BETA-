#pragma once

#include <cstddef>
#include <string>
#include <vector>

namespace geodecor {

// Read-only facts copied from a live Geometry Dash GameObject.
// This core type intentionally has no Geode dependency so it can be tested
// with the portable C++ test target.
struct BlockObjectSnapshot {
    int objectId = -1;
    std::string frameName;
    bool isSolidColorBlock = false;
    bool isSlope = false;
    bool isDecoration = false;
    bool hasGlowSprite = false;
    bool isTrigger = false;
    bool isStartPosition = false;
    bool hasParticles = false;
};

struct BlockCatalogEntry {
    int objectId = -1;
    std::string frameName;
    std::size_t count = 0;
    bool isSolidColorBlock = false;
    bool isSlope = false;
    bool isDecoration = false;
    bool hasGlowSprite = false;
    bool isTrigger = false;
    bool isStartPosition = false;
    bool hasParticles = false;
};

struct BlockCatalogReport {
    std::size_t scannedObjects = 0;
    std::size_t invalidObjectIds = 0;
    std::size_t uniqueObjectIds = 0;
    std::size_t objectTypesWithGlow = 0;
    std::size_t objectTypesWithParticles = 0;
    std::size_t selectableObjectTypes = 0;
    std::vector<BlockCatalogEntry> entries;
};

enum class BlockCatalogFilter {
    All,
    NonTriggerObjects,
    SolidColorBlocks,
    Slopes,
    Decorations,
    GlowObjects,
    ParticleObjects,
    Triggers,
    StartPositions
};

// Builds a stable inventory grouped by object ID. Duplicate observations are
// merged; flags are ORed and counts are accumulated. Invalid IDs are skipped.
BlockCatalogReport buildBlockCatalog(
    const std::vector<BlockObjectSnapshot>& snapshots);

// Returns IDs in catalog order (count descending, then ID ascending).
std::vector<int> getBlockCatalogIds(
    const BlockCatalogReport& report,
    BlockCatalogFilter filter);

// Trigger and start-position objects are never offered by the default
// decoration-candidate filter. This is a type filter, not a collision check.
bool isSelectableDecorationObject(const BlockCatalogEntry& entry) noexcept;

const BlockCatalogEntry* findBlockCatalogEntry(
    const BlockCatalogReport& report,
    int objectId) noexcept;

} // namespace geodecor
