#include "DecorationEngine.hpp"
#include "DecorationPlanner.hpp"
#include "LevelString.hpp"

#include <stdexcept>
#include <string>
#include <vector>

using namespace geodecor;

namespace {
void require(bool condition, const char* message) {
    if (!condition) {
        throw std::runtime_error(message);
    }
}

LevelObject makeObject(int id, double x, double y) {
    LevelObject object;
    object.properties[1] = std::to_string(id);
    object.properties[2] = std::to_string(x);
    object.properties[3] = std::to_string(y);
    return object;
}
}

int main() {
    LevelDocument level;
    level.objects.push_back(makeObject(1, 0.0, 0.0));

    const std::vector<BlockReference> references = {
        {1, "Source Block", "solid", "", {}}
    };

    DecorationSettings settings;
    settings.blockSet = BlockSet::Solid;
    settings.style = DecorationStyle::Modern;
    settings.intensity = DecorationIntensity::Heavy;
    settings.glowEnabled = true;
    settings.useExplicitObjectSelection = true;
    settings.selectedDecorationIds = {700, 702};
    settings.selectedGlowIds = {702};
    settings.selectedEffectIds = {703};
    settings.effectsEnabled = true;

    const auto plan = buildDecorationPlan(level, references, settings);
    require(plan.candidates.size() == 1, "source candidate was not created");

    const std::vector<DecorationAsset> catalog = {
        {700, DecorationStyle::Modern, "detail", 0.0, 40.0, 5.0, false},
        {701, DecorationStyle::Modern, "detail", 0.0, 60.0, 5.0, false},
        {702, DecorationStyle::Modern, "glow", 0.0, 80.0, 5.0, true},
        {703, DecorationStyle::Modern, "effect", 0.0, 100.0, 5.0, false}
    };

    const auto generated = generateDecorationProposals(level, plan, catalog, 5.0);
    require(generated.proposedDecorations == 3, "explicit selection should allow exactly three assets");
    require(generated.decorations[0].decorationObjectId == 700, "first selected asset mismatch");
    require(generated.decorations[1].decorationObjectId == 702, "selected glow asset mismatch");
    require(generated.decorations[2].decorationObjectId == 703, "selected effect asset mismatch");

    settings.glowEnabled = false;
    const auto noGlowPlan = buildDecorationPlan(level, references, settings);
    const auto noGlow = generateDecorationProposals(level, noGlowPlan, catalog, 5.0);
    require(noGlow.proposedDecorations == 2, "disabled glow should reject glow assets");

    settings.glowEnabled = true;
    settings.effectsEnabled = false;
    const auto noEffectsPlan = buildDecorationPlan(level, references, settings);
    const auto noEffects = generateDecorationProposals(level, noEffectsPlan, catalog, 5.0);
    require(noEffects.proposedDecorations == 2, "disabled effects should reject effect assets");

    settings.effectsEnabled = true;
    settings.selectedDecorationIds.clear();
    settings.selectedGlowIds.clear();
    settings.selectedEffectIds.clear();
    const auto emptyPlan = buildDecorationPlan(level, references, settings);
    const auto emptySelection = generateDecorationProposals(level, emptyPlan, catalog, 5.0);
    require(emptySelection.proposedDecorations == 0, "empty explicit selection must not fall back to all assets");

    return 0;
}
