cmake_minimum_required(VERSION 3.20)
project(GeoDecorCoreTests LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

add_executable(geodecor-core-tests
    test_main.cpp
    ../src/core/LevelString.cpp
    ../src/core/ThemeAnalyzer.cpp
    ../src/core/BlockDNA.cpp
    ../src/core/BlockCatalog.cpp
    ../src/core/DecorationPlanner.cpp
    ../src/core/DecorationEngine.cpp
)

target_include_directories(geodecor-core-tests PRIVATE ../src/core)

add_executable(geodecor-block-catalog-tests
    test_block_catalog.cpp
    ../src/core/BlockCatalog.cpp
)
target_include_directories(geodecor-block-catalog-tests PRIVATE ../src/core)

add_executable(geodecor-selection-tests
    test_decoration_selection.cpp
    ../src/core/LevelString.cpp
    ../src/core/BlockDNA.cpp
    ../src/core/DecorationPlanner.cpp
    ../src/core/DecorationEngine.cpp
)
target_include_directories(geodecor-selection-tests PRIVATE ../src/core)

foreach(target
    geodecor-core-tests
    geodecor-block-catalog-tests
    geodecor-selection-tests
)
    if (MSVC)
        target_compile_options(${target} PRIVATE /W4 /WX)
    else()
        target_compile_options(${target} PRIVATE -Wall -Wextra -Wpedantic -Werror)
    endif()
endforeach()

enable_testing()
add_test(NAME geodecor-core-tests COMMAND geodecor-core-tests)
add_test(NAME geodecor-block-catalog-tests COMMAND geodecor-block-catalog-tests)
add_test(NAME geodecor-selection-tests COMMAND geodecor-selection-tests)
