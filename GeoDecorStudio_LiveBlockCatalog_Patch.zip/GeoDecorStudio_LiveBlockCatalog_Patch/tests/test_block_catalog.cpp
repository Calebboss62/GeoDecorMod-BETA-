#include "BlockCatalog.hpp"

#include <stdexcept>
#include <string>
#include <vector>

using namespace geodecor;

namespace {
void require(bool condition, const char* message) {
    if (!condition) {
        throw std::runtime_error(message);
    }
}
}

int main() {
    const std::vector<BlockObjectSnapshot> snapshots = {
        {1, "square_01_001.png", true, false, false, false, false, false, false},
        {2, "slope_01_001.png", false, true, false, true, false, false, false},
        {2, "slope_01_001.png", false, true, false, true, false, false, false},
        {3, "detail_01_001.png", false, false, true, true, false, false, true},
        {4, "trigger_001.png", false, false, false, false, true, false, false},
        {5, "startpos_001.png", false, false, false, false, false, true, false},
        {0, "", false, false, false, false, false, false, false}
    };

    const auto report = buildBlockCatalog(snapshots);
    require(report.scannedObjects == 7, "scanned object count mismatch");
    require(report.invalidObjectIds == 1, "invalid ID count mismatch");
    require(report.uniqueObjectIds == 5, "unique ID count mismatch");
    require(report.objectTypesWithGlow == 2, "glow type count mismatch");
    require(report.objectTypesWithParticles == 1, "particle type count mismatch");
    require(report.selectableObjectTypes == 3, "selectable type count mismatch");

    require(report.entries.front().objectId == 2, "entries must sort by count descending");
    require(report.entries.front().count == 2, "duplicate object count mismatch");
    require(report.entries.front().hasGlowSprite, "glow flag should be merged");
    require(report.entries.front().isSlope, "slope flag should be merged");

    const auto* detail = findBlockCatalogEntry(report, 3);
    require(detail != nullptr, "catalog lookup failed");
    require(detail->frameName == "detail_01_001.png", "frame name was not retained");
    require(detail->isDecoration, "decoration flag mismatch");
    require(detail->hasParticles, "particle flag mismatch");

    const auto allIds = getBlockCatalogIds(report, BlockCatalogFilter::All);
    require(allIds.size() == 5, "all filter mismatch");

    const auto glowIds = getBlockCatalogIds(report, BlockCatalogFilter::GlowObjects);
    require(glowIds.size() == 2 && glowIds[0] == 2 && glowIds[1] == 3,
        "glow filter mismatch");

    const auto slopeIds = getBlockCatalogIds(report, BlockCatalogFilter::Slopes);
    require(slopeIds.size() == 1 && slopeIds[0] == 2, "slope filter mismatch");

    const auto solidColorIds = getBlockCatalogIds(report, BlockCatalogFilter::SolidColorBlocks);
    require(solidColorIds.size() == 1 && solidColorIds[0] == 1,
        "solid-color-block filter mismatch");

    const auto decorationIds = getBlockCatalogIds(report, BlockCatalogFilter::Decorations);
    require(decorationIds.size() == 1 && decorationIds[0] == 3,
        "decoration filter mismatch");

    const auto particleIds = getBlockCatalogIds(report, BlockCatalogFilter::ParticleObjects);
    require(particleIds.size() == 1 && particleIds[0] == 3,
        "particle filter mismatch");

    const auto nonTriggerIds = getBlockCatalogIds(report, BlockCatalogFilter::NonTriggerObjects);
    require(nonTriggerIds.size() == 3, "non-trigger filter size mismatch");
    require(nonTriggerIds[0] == 2 && nonTriggerIds[1] == 1 && nonTriggerIds[2] == 3,
        "non-trigger filter order mismatch");

    const auto triggerIds = getBlockCatalogIds(report, BlockCatalogFilter::Triggers);
    require(triggerIds.size() == 1 && triggerIds[0] == 4, "trigger filter mismatch");

    const auto startIds = getBlockCatalogIds(report, BlockCatalogFilter::StartPositions);
    require(startIds.size() == 1 && startIds[0] == 5, "start-position filter mismatch");

    require(findBlockCatalogEntry(report, 999) == nullptr, "unknown ID lookup should fail");
    return 0;
}
