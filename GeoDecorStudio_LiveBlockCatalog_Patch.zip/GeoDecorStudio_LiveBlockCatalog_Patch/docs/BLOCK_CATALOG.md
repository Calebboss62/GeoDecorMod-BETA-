# Live Block Catalog

## What this milestone adds

GeoDecor can now turn the objects already present in the open editor into a stable, grouped catalog. Each catalog entry includes:

- Geometry Dash object ID (the stable key)
- Sprite-frame resource name when the game resolves one
- How many instances of that ID are in the current layout
- Runtime metadata flags for special solid-color blocks, slopes, decoration objects, glow sprites, triggers, start positions, and particle emitters

The core catalog is portable C++ and is tested independently of Geode. `LiveBlockCatalog.cpp` is the Android/Geode adapter that reads the live `GameObject` instances and passes plain snapshots into the core.

## Important scope limit

This first catalog lists object IDs found in the **currently open level**. It does not yet enumerate every object available in the global Geometry Dash editor palette. It also does not guess categories from numeric ID ranges or invent missing object IDs. A global palette browser and thumbnail picker are a later milestone.

`isSolidColorBlock` is the exact game flag of that name; it does not mean every object that can behave as solid geometry. `hasGlowSprite` means the loaded live object currently has a glow sprite and does not set the game's no-glow flag. `hasParticles` reports the object's particle metadata; it is not a claim that every effect object is covered.

The `NonTriggerObjects` filter only excludes triggers and start positions. It is **not** a gameplay collision or player-path safety test. The decoration engine's placement safety checks remain separate.

## Android 2.2081 binding verification

The adapter uses fields and methods present in `geode-sdk/bindings` at `bindings/2.2081/GeometryDash.bro`:

- `ObjectToolbox::sharedState()`
- `ObjectToolbox::intKeyToFrame(int)`
- `GameObject::m_objectID`
- `GameObject::m_isSolidColorBlock`
- `GameObject::m_slopeUphill` and `m_slopeIsHazard`
- `GameObject::m_isDecoration` and `m_isDecoration2`
- `GameObject::m_glowSprite` and `m_hasNoGlow`
- `GameObject::m_isTrigger` and `m_isStartPos`
- `GameObject::m_hasParticles`

Source: https://github.com/geode-sdk/bindings/blob/main/bindings/2.2081/GeometryDash.bro

The Geode/Android adapter is included in the mod target, but it still needs a fresh Android64 GitHub Actions build after this patch is committed. Portable tests do not prove the Geode adapter compiles.

## Individual decoration selection

`DecorationSettings` now has an explicit selection mode:

- `useExplicitObjectSelection = true` means an empty list selects nothing; it never silently falls back to every asset.
- `selectedDecorationIds` controls ordinary decoration assets.
- `selectedGlowIds` is an additional allow-list for assets with `requiresGlow = true`.
- `selectedEffectIds` controls assets whose category is `effect` or `effects`.
- `effectsEnabled` and `glowEnabled` are master switches.

When explicit selection is off (the default), existing planner behavior is preserved. When it is on, the generator only considers the selected IDs. Glow and effect assets need both their ID selection and their master switch.

## Calling the live adapter from the workspace

`src/main.cpp` can include:

```cpp
#include "integration/LiveBlockCatalog.hpp"
```

Inside the existing `onScanLevel` handler, after `getAllObjects()` succeeds:

```cpp
auto catalog = geodecor::scanLiveBlockCatalog(objects);
```

Then display the report's `entries` (object ID, `frameName`, `count`, and flags). This patch intentionally does not replace `main.cpp`; the next UI milestone will turn these catalog entries into individual selectable rows and persistent user settings.

## Safety

This module only reads live object metadata. It does not call `createWithKey`, add objects to the editor, alter colors, or change the user's level. It produces catalog data only. The current decoration engine still returns proposals rather than mutating the level.
