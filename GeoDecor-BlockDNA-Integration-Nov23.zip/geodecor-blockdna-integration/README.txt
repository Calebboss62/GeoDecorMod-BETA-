GeoDecor Studio — Live Scanner / BlockDNA Integration

WHAT THIS PATCH DOES
- Reuses the existing geodecor::analyzeBlockDNA(liveLevel) function.
- Ranks the live editor's valid object IDs by frequency using BlockDNAEntry.
- Keeps the existing scan popup and read-only behavior.
- Does not place decorations or modify Geometry Dash level objects.

IMPORTANT
This patch is prepared against the inspected GitHub main.cpp version. The script
checks every expected source section before writing. If your file differs, it
stops without changing main.cpp.

HOW TO APPLY IN CODESPACES
1. Upload this ZIP into the repository workspace root (the same level as
   CMakeLists.txt).
2. Open the terminal at the repository root and run these exact commands:

   unzip -o geodecor-blockdna-integration.zip -d /tmp
   python3 /tmp/geodecor-blockdna-integration/apply.py

   (Use the ZIP's actual filename if it differs.)

3. Inspect the change:

   git diff -- src/main.cpp

4. Run the repository's existing tests / GitHub Actions before committing.
   If the diff looks correct and tests pass, commit it with a message such as:

   Connect live scan to BlockDNA inventory

ROLLBACK
Before committing, you can undo this one-file change with:

   git restore src/main.cpp

This discards changes to src/main.cpp, so use it only if you have no other
uncommitted edits in that file.

SCOPE / NEXT MILESTONE
This is the integration foundation, not the finished Live Block Catalog UI.
The next milestone is to present richer catalog metadata (categories, sprite
frames, glow/details metadata) and then feed user-selected catalog entries into
the DecorationPlanner/DecorationEngine proposal flow. Decoration placement
must remain preview-only until an explicit, separately verified apply step.
