#!/usr/bin/env python3
"""Safely connect GeoDecor's live editor scan to the existing BlockDNA analyzer."""
from pathlib import Path
import sys

path = Path("src/main.cpp")
if not path.is_file():
    sys.exit("ERROR: Run this script from the GeoDecor repository root (src/main.cpp was not found).")

source = path.read_text(encoding="utf-8")
original = source


def replace_once(old: str, new: str, label: str) -> None:
    global source
    count = source.count(old)
    if count != 1:
        raise RuntimeError(
            f"Expected exactly one match for {label}, found {count}. "
            "No file has been changed; your main.cpp may differ from the inspected version."
        )
    source = source.replace(old, new, 1)


if '#include "core/BlockDNA.hpp"' not in source:
    sys.exit('ERROR: main.cpp does not include "core/BlockDNA.hpp". No file changed.')

replace_once(
    "        std::map<int, std::size_t> objectCounts;\n\n"
    "geodecor::LevelDocument liveLevel;\n\n"
    "std::size_t totalObjects = 0;\n"
    "std::size_t invalidObjects = 0;",
    "        geodecor::LevelDocument liveLevel;\n"
    "        std::size_t invalidObjects = 0;",
    "scanner inventory declarations",
)

replace_once(
    "objectCounts[objectId]++;\ntotalObjects++;",
    "",
    "manual object counting inside the scan loop",
)

replace_once(
    "        // Convert the inventory into a sortable list.\n"
    "        std::vector<std::pair<int, std::size_t>> ranked;\n\n"
    "        for (const auto& entry : objectCounts) {\n"
    "            ranked.push_back(entry);\n"
    "        }\n\n"
    "        std::sort(\n"
    "            ranked.begin(),\n"
    "            ranked.end(),\n"
    "            [](const auto& a, const auto& b) {\n"
    "                if (a.second != b.second)\n"
    "                    return a.second > b.second;\n\n"
    "                return a.first < b.first;\n"
    "            }\n"
    "        );",
    "        // Use the shared BlockDNA analyzer for the live level inventory.\n"
    "        const auto dnaReport = geodecor::analyzeBlockDNA(liveLevel);\n"
    "        const std::size_t totalObjects = dnaReport.totalObjects;\n\n"
    "        // Sort catalog entries by frequency, then by object ID.\n"
    "        auto ranked = dnaReport.entries;\n"
    "        std::sort(\n"
    "            ranked.begin(),\n"
    "            ranked.end(),\n"
    "            [](const auto& a, const auto& b) {\n"
    "                if (a.count != b.count)\n"
    "                    return a.count > b.count;\n\n"
    "                return a.objectId < b.objectId;\n"
    "            }\n"
    "        );",
    "inventory sorting block",
)

if source.count("objectCounts.size()") != 2:
    raise RuntimeError(
        f"Expected exactly two objectCounts.size() references, found {source.count('objectCounts.size()')}. "
        "No file has been changed."
    )
source = source.replace("objectCounts.size()", "dnaReport.entries.size()")
replace_once("ranked[i].first", "ranked[i].objectId", "ranked object ID in scan report")
replace_once("ranked[i].second", "ranked[i].count", "ranked frequency in scan report")

# <map> was used only by the old local counting map.
if source.count("#include <map>\n") == 1:
    source = source.replace("#include <map>\n", "", 1)

path.write_text(source, encoding="utf-8")
print("SUCCESS: src/main.cpp now uses geodecor::analyzeBlockDNA() for its live scan inventory.")
print("The scan remains read-only; this change does not add or remove Geometry Dash level objects.")
print("Next: inspect with `git diff -- src/main.cpp`, then run the existing CI/tests before committing.")
